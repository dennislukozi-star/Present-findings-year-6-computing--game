let questions = [
{
question:"Which is best for comparing favourite fruits?",
answers:["Bar Chart","Long Story","Random Picture","Secret Code"],
correct:0
},
{
question:"Which is easiest for younger children to read?",
answers:["Pictogram","Spreadsheet Code","Essay","Paragraph"],
correct:0
},
{
question:"Which shows exact numbers clearly?",
answers:["Table","Song","Cartoon","Guess"],
correct:0
},
{
question:"After showing data you should add?",
answers:["A conclusion sentence","Nothing","A joke","Hide the data"],
correct:0
},
{
question:"Which graph compares categories quickly?",
answers:["Bar Chart","Poem","Drawing","Blank page"],
correct:0
}
];

let currentQuestion = 0;
let score = 0;

const questionElement = document.getElementById("question");
const answersElement = document.getElementById("answers");
const scoreElement = document.getElementById("score");
const messageElement = document.getElementById("message");
const nextBtn = document.getElementById("nextBtn");

function loadQuestion(){

messageElement.textContent="";
nextBtn.style.display="none";

let q = questions[currentQuestion];

questionElement.textContent = q.question;

answersElement.innerHTML="";

q.answers.forEach((answer,index)=>{

let button = document.createElement("button");
button.textContent = answer;

button.onclick = ()=>checkAnswer(index);

answersElement.appendChild(button);

});

}

function checkAnswer(index){

let correct = questions[currentQuestion].correct;

if(index === correct){

score++;
scoreElement.textContent = score;
messageElement.textContent = "Correct!";
messageElement.style.color = "green";

}else{

messageElement.textContent = "Not quite.";
messageElement.style.color = "red";

}

nextBtn.style.display="inline-block";

}

nextBtn.onclick = ()=>{

currentQuestion++;

if(currentQuestion < questions.length){

loadQuestion();

}else{

questionElement.textContent = "Game Finished!";
answersElement.innerHTML="";
messageElement.textContent = "Your score: " + score + " / " + questions.length;

nextBtn.style.display="none";

}

}

loadQuestion();
